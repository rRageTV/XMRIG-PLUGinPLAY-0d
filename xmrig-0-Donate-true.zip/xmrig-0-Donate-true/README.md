# xmrig-PLUGandPLAY
Generate the xmrig suite (miner or proxy) with SSL/TLS call one script:

```
git clone https://github.com/enwillyado/xmrig-PLUGandPLAY/
cd xmrig-PLUGandPLAY
sh build.sh
```

## Donations
* XMR: `433hhduFBtwVXtQiTTTeqyZsB36XaBLJB6bcQfnqqMs5RJitdpi8xBN21hWiEfuPp2hytmf1cshgK5Grgo6QUvLZCP2QSMi`
* BTC: `13MTEjDv8JmS4suaRx6CcWNthR1vwPr7Ce`
* DOGE: `DHif8RTy8E6K4b71u3fXXSk7AEyiuN2sUi`

## Contacts
* xmrig@enwillyado.com
* [telegram](https://telegram.me/enWILLYado)

¡Se habla español!
